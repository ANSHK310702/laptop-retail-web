/**
*Author: Ansh Kalra 103171831
*Target: enquire.html
*Purpose: Javascript
*Created: 23-04-2021
*Last updated:25-04-2021
*Credits:(Any guidance/help/code?)
*/

"use strict";
	
function validate() {
	var errMsg = "";
	var result = true;
	var quantity = document.getElementById("Quantity").value; 
	if (quantity < 0){
		errMsg = errMsg +"Your quantity must be positive.\n"	//if the quantity is negative then it will pop out error message 
		result = false;
	}
	
	if(document.getElementById("product").value == ""){
		errMsg = errMsg +"You must enter the Product.\n";	//if Please select option is selected it will display error message
		result = false;
	}
	
	 var postcode = document.getElementById("postcode").value;
	var state = document.getElementById("state").options[document.getElementById("state").selectedIndex].text;

	var x;
 //VIC = 3 OR 8, NSW = 1 OR 2 ,QLD = 4 OR 9 ,NT = 0 ,WA = 6 ,SA=5 ,TAS=7 ,ACT= 0.
	 switch (state) {
		case "Please Select":
			return false;
		case "VIC":
			x = new RegExp(/(3|8)\d+\d+\d+/);
			break;
		 case "NSW":
			x = new RegExp(/(1|2)\d+\d+\d+/);
			break;
		 case "QLD":
			x = new RegExp(/(4|9)\d+\d+\d+/);
			break;
		 case "NT":
			x = new RegExp(/0\d+\d+\d+/);
			break;
		 case "WA":
			x = new RegExp(/6\d+\d+\d+/);
			break;
		 case "SA":
			x = new RegExp(/5\d+\d+\d+/);
			break;
		 case "TAS":
			x = new RegExp(/7\d+\d+\d+/);
			break;
		 case "ACT":
			x = new RegExp(/0\d+\d+\d+/);
			break;
	 }
	 if(!postcode.match(x)){
	   errMsg = errMsg + "State and postcode do not match with each other.\nPlease check it\n";
	   result = false;
	 }

	if (errMsg != ""){
		alert(errMsg);
	}
	
	if (result){
		storeDetails()
	}
	return result;
}

function storeDetails(){
	//session storage is used here to store the data from this webpage.
	sessionStorage.firstname = document.getElementById("Firstname").value;
	sessionStorage.lastname = document.getElementById("Lastname").value;
	sessionStorage.email = document.getElementById("e-mail").value;
	sessionStorage.phonenumber = document.getElementById("phonenumber").value;
	sessionStorage.streetaddress = document.getElementById("streetaddress").value;
	sessionStorage.suburbtown = document.getElementById("suburbtown").value;
	sessionStorage.postcode = document.getElementById("postcode").value;
	sessionStorage.quantity = document.getElementById("Quantity").value;
	var product = "";
	if(document.getElementById("1").selected) product = "microsoft_surface_laptop_3";
	if(document.getElementById("2").selected) product = ", dell_xps_13";
	if(document.getElementById("3").selected) product = ", asus_zenbook_13";
	sessionStorage.product = product;
	
}
	



function init() {
	var regForm = document.getElementById("regform");// get ref to the HTML element
	regForm.onsubmit = validate; 
	
	
}




window.onload = init;