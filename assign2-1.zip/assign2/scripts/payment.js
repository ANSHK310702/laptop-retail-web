/**
*Author: Ansh Kalra 103171831
*Target: payment.html
*Purpose: Javascript
*Created: 23-04-2021
*Last updated:25-04-2021
*Credits:(Any guidance/help/code?)
*/

"use strict";

function validate(){
	var errMsg = "";
	var result = true;
	if(document.getElementById("cardtype").value == "none"){	
		errMsg = errMsg +"You must enter the Credit Card Type.\n(no valid default)";
		//here error message pops out when cardtype of none value is selected	
		result = false;
	}
	
	var nameoncard = document.getElementById("Nameoncard").value;
	if(!nameoncard.match(/^[a-zA-Z ]+$/)){
		errMsg = errMsg + "Your Card Name must only contain alpha characters,space.\n"
		// if the card name contains something other then alpha characters and space it will pops out error message
		result = false;
	}
	else if(nameoncard.length > 40){
		errMsg = errMsg +"Your Card name must only contains 40 characters.\n"
		//here card name also pops out error when name on card is greater than 40 characters
		result = false;
	}
	var cardNumber = document.getElementById("cardnumber").value;
	var cardType = document.getElementById("cardtype").options[document.getElementById("cardtype").selectedIndex].text;
	
	var x;
	//Visa cards have 16 digits and start with a 4, MasterCard have 16 digits and start with digits 51 through to 55,American Express has 15 digits and starts with 34 or 37.
		switch (cardType) {
			case "Please Select":
				return false;
			case "Visa":
				x = new RegExp("^4\[0-9]{15}$");
				break;
			 case "Mastercard":
				x = new RegExp("^5[1-5]\[0-9]{14}$");
				break;
			 case "American Express":
				x = new RegExp("^3(4|7)\[0-9]{13}$");
				break;
		}
	 if(!cardNumber.match(x)){
	   errMsg = errMsg + "Your card number not matched up with the card type\n";
	   result = false;
	 }
	
	if (errMsg != ""){
		alert(errMsg);
	}
	
	return result;
}

function calcCost(product,quantity){
	var cost = 0;
	//in this function cost is calculated
	if (product.search("microsoft_surface_laptop_3") != -1) cost = 3278;
	if (product.search(", dell_xps_13")!= -1) cost += 2855;
	if (product.search(", asus_zenbook_13")!= -1) cost += 1544;
	return cost * quantity;
}

function getDetails(){
	var cost = calcCost(sessionStorage.product,sessionStorage.quantity);
	if(sessionStorage.firstname != undefined){    //if sessionStorage for username is not empty
		//confirmation text
		document.getElementById("confirm_name").textContent = sessionStorage.firstname + " " + sessionStorage.lastname;
		document.getElementById("confirm_email").textContent =sessionStorage.email;
		document.getElementById("confirm_phone").textContent = sessionStorage.phonenumber;
		document.getElementById("confirm_address").textContent = sessionStorage.streetaddress + " " + sessionStorage.suburbtown;
		document.getElementById("confirm_product").textContent = sessionStorage.product;
		document.getElementById("confirm_cost").textContent = cost;
		document.getElementById("confirm_state").textContent = sessionStorage.postcode;
		// hidden fields 
		document.getElementById("Firstname").value = sessionStorage.firstname;
		document.getElementById("Lastname").value = sessionStorage.lastname;
		document.getElementById("e-mail").value = sessionStorage.email;
		document.getElementById("phonenumber").value = sessionStorage.phonenumber;
		document.getElementById("streetaddress").value = sessionStorage.streetaddress;
		document.getElementById("suburbtown").value = sessionStorage.suburbtown;
		document.getElementById("product").value = sessionStorage.product;
		document.getElementById("cost").value = cost;
	}

}

function cancelDetails(){
	window.location = "index.html";	//here clicking on cancel will redirects page to enquiry page and destroys stored data
}




function init() {
	var bookform = document.getElementById("bookform");// get ref to the HTML element
	bookform.onsubmit = validate;
	bookform.onmouseover = getDetails;
	var cancel = document.getElementById("cancelButton");
	cancel.onclick = cancelDetails;
}




window.onload = init;